package ru.uniyar

import org.http4k.core.*
import ru.uniyar.formats.JacksonMessage
import ru.uniyar.formats.imageFile
import ru.uniyar.formats.jacksonMessageLens
import ru.uniyar.formats.nameField
import ru.uniyar.formats.strictFormBody
import ru.uniyar.models.PebbleViewModel
import org.http4k.core.ContentType.Companion.TEXT_HTML
import org.http4k.core.Method.GET
import org.http4k.core.Method.POST
import org.http4k.core.Status.Companion.OK
import org.http4k.filter.DebuggingFilters.PrintRequest
import org.http4k.routing.ResourceLoader
import org.http4k.routing.bind
import org.http4k.routing.routes
import org.http4k.routing.static
import org.http4k.server.Netty
import org.http4k.server.asServer
import org.http4k.template.PebbleTemplates
import org.http4k.template.viewModel
import ru.uniyar.web.handlers.InfoAboutTownHandler
import ru.uniyar.web.handlers.ListOfTownsHandler
import ru.uniyar.web.handlers.MainMenuHandler
import ru.uniyar.web.hendlers.RedirectToMainMenu


fun router() =
    routes(
        "/ping" bind GET to { Response(OK).body("pong") },
        "/" bind GET to RedirectToMainMenu(),
        "/spisok" bind GET to ListOfTownsHandler(),
        "/bobruysk" bind GET to InfoAboutTownHandler(),
        "/mainmenu" bind GET to MainMenuHandler(),
        static(ResourceLoader.Classpath("ru/uniyar/public")),
    )

fun main() {
    val app = router()
    val printingApp: HttpHandler = Filter.NoOp.then(app)
    val server = app.asServer(Netty(9000)).start()

    println("Server started on http://localhost:" + server.port())
}