package ru.uniyar.web.handlers

import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import ru.uniyar.domain.Towns
import ru.uniyar.web.view.MainMemuView

class MainMenuHandler : HttpHandler{

    val townss = Towns.MainMenu()
    private val mmv = MainMemuView()

    override fun invoke(request: Request): Response {
        return Response(Status.OK).body(mmv.showData(townss))
    }

}