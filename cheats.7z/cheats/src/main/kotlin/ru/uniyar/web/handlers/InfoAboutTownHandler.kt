package ru.uniyar.web.handlers

import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import ru.uniyar.domain.Towns
import ru.uniyar.web.view.PeopleView

class InfoAboutTownHandler : HttpHandler{

    val infotown = Towns.ListOfTowns.InfoAboutTown()
    private val pv = PeopleView()

    override fun invoke(request: Request): Response {
        return Response(Status.OK).body(pv.showData(infotown))
    }

}