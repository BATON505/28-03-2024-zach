package ru.uniyar.web.handlers

import org.http4k.core.HttpHandler
import org.http4k.core.Request
import org.http4k.core.Response
import org.http4k.core.Status
import ru.uniyar.domain.Towns
import ru.uniyar.web.view.ListOfTownsView

class ListOfTownsHandler : HttpHandler{

    val towns = Towns.ListOfTowns()
    private val lot = ListOfTownsView()

    override fun invoke(request: Request): Response {
        return Response(Status.OK).body(lot.showData(towns))
    }

}