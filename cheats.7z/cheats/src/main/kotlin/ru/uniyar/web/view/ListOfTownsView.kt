package ru.uniyar.web.view

import ru.uniyar.domain.*

class ListOfTownsView {

    fun showData(data: Towns.ListOfTowns): String =
        """
            <!doctype html>
            <html lang="ru">
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>Информация</title>
                <link href="css/bootstrap.min.css" rel="stylesheet">
            </head>
            <body>
            
            <nav class="navbar navbar-expand-lg bg-body-tertiary">
              <div class="container-fluid">
                <a class="navbar-brand">Панель навигации</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Переключатель навигации">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                  <ul class="navbar-nav">
                    <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="/">Главное меню</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="/spisok">Список городов</a>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>
            
            <h1>Города, подавшие заявку на благоустройство территории</h1>
            <p>
            ${data.DateAndTimeOfFormation()}
            </p>
            <p>
            <a href="http://localhost:9000/bobruysk">${data.townName()}! Территория: ${data.terraName()}, далее координаты: ${data.coordinates()}</a>
            </p>
            <script src="js/bootstrap.bundle.min.js"></script>
            </body>
            </html>
        """.trimIndent()
}
//<nav><a href="http://localhost:9000/mainmenu">Главное меню</a> <a href="http://localhost:9000/spisok">    Список городов</a></nav>