package ru.uniyar.models

import org.http4k.template.ViewModel

data class PebbleViewModel(val description: String) : ViewModel
