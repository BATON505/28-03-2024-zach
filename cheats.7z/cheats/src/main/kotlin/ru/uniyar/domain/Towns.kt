package ru.uniyar.domain

import java.text.SimpleDateFormat
import java.util.*

open class Towns {
    fun DateAndTimeOfFormation(): String {
        val dateFormat = SimpleDateFormat("dd.MM.yyyy")
        val currentDate = Date()
        return dateFormat.format(currentDate)
    }

    class MainMenu: Towns() {
        fun listOfTowns(): String {
            return "Города, подавшие заявку на благоустройство"
        }
    }

    class ListOfTowns: Towns() {
        fun townName(): String {
            return "Бобруйск"
        }

        fun terraName(): String {
            return "Сквер дружбы"
        }

        fun coordinates(): String {
            return "Широта: 53.144711\nДолгота: 29.234063"
        }


    class InfoAboutTown: Towns() {

        fun textAboutPlace(): String {
            return "XVI Международный фестиваль народного творчества «Венок дружбы» богат знаковыми мероприятиями. Одним из них стала торжественная церемония закладки сквера Дружбы в Ленинском районе любимого города Бобруйска.\n" +
                    "\n" +
                    "После официальной части мероприятия представители делегаций городов-побратимов на территории будущего сквера высадили березы, которые будут олицетворять дружбу, любовь и мир между народами."
        }

        fun peopleList(): MutableList<String> {
            val lyudi = mutableListOf("Иван Петров 04.05.2020\n" + "\nПётр Иванов 05.06.2021\n" + "\nАлександр Лукашенко 06.07.2022\n")
            return lyudi
        }


    }


}
    }




















/*
    fun coordinates(shirota: Integer, dolgota: Integer): String {
        return "Широта: $shirota,  долгота: $dolgota"
    }

    fun personName(name: String, dateOfSupport: String): String {
        return "$name поддерживает населённый пункт с $dateOfSupport!"
    }
*/