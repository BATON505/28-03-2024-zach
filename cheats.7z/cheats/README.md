# Laba1

## Package
```
./gradlew distZip
```

